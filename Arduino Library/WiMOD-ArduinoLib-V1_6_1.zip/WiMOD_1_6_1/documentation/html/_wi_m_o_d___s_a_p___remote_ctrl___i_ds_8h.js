var _wi_m_o_d___s_a_p___remote_ctrl___i_ds_8h =
[
    [ "TWiMODLR_RemoteCtrl_BtnPressed", "struct_t_wi_m_o_d_l_r___remote_ctrl___btn_pressed.html", "struct_t_wi_m_o_d_l_r___remote_ctrl___btn_pressed" ],
    [ "REMOTE_CTRL_BUTTON_ONE", "_wi_m_o_d___s_a_p___remote_ctrl___i_ds_8h.html#aeca896538396d51ef643d3a4104f5740", null ],
    [ "REMOTE_CTRL_BUTTON_THREE", "_wi_m_o_d___s_a_p___remote_ctrl___i_ds_8h.html#ac181e04a0f8486d810bc0e3ca6f16c9b", null ],
    [ "REMOTE_CTRL_BUTTON_TWO", "_wi_m_o_d___s_a_p___remote_ctrl___i_ds_8h.html#a93119462d83d5d40f2503dcd3f6578cf", null ],
    [ "TWiMODLR_RemoteCtrl_BtnPressed", "_wi_m_o_d___s_a_p___remote_ctrl___i_ds_8h.html#ac240c06860365e46d6d18ae64c021786", null ]
];