var searchData=
[
  ['voltage',['Voltage',['../struct_t_wi_m_o_d_l_r___sensor_app___sensor_data.html#a38c70cd86f3f15bc28e7abaa7c4f12de',1,'TWiMODLR_SensorApp_SensorData']]]
];
