var searchData=
[
  ['sensorapp_5fmode_5foff',['SensorApp_Mode_Off',['../_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#a49817714374ebcf022b82b6239583859ac1a0d03c3d09ac0d89cf32dfbb95b0a2',1,'WiMOD_SAP_SensorApp_IDs.h']]],
  ['sensorapp_5fmode_5fsensordatareceiver',['SensorApp_Mode_SensorDataReceiver',['../_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#a49817714374ebcf022b82b6239583859a18ae7a858c928cc6665a0f73c52db3fe',1,'WiMOD_SAP_SensorApp_IDs.h']]],
  ['sensorapp_5fmode_5fsensordatatransmitter',['SensorApp_Mode_SensorDataTransmitter',['../_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#a49817714374ebcf022b82b6239583859a25e4df1c46206817ea862461981f4cce',1,'WiMOD_SAP_SensorApp_IDs.h']]]
];
