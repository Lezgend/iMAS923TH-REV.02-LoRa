var _wi_m_o_d___s_a_p___remote_ctrl_8h =
[
    [ "WiMOD_SAP_RemoteCtrl", "class_wi_m_o_d___s_a_p___remote_ctrl.html", "class_wi_m_o_d___s_a_p___remote_ctrl" ],
    [ "TRemoteCtrlBtnPressedIndicationCallback", "_wi_m_o_d___s_a_p___remote_ctrl_8h.html#a0f67678ed14348254797518ca4112aae", null ]
];