var _freq_calc___s_x1280_8h =
[
    [ "FreqCalcSX1280_calcFreqToRegister", "_freq_calc___s_x1280_8h.html#a57be6009b2c5914f19a6702c66be9bf5", null ],
    [ "FreqCalcSX1280_calcRegisterToFreq", "_freq_calc___s_x1280_8h.html#a45588b7d31ba10861e4760114ddff955", null ]
];