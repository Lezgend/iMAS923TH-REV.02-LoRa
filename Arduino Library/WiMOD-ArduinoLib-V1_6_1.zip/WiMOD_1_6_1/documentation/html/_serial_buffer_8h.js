var _serial_buffer_8h =
[
    [ "SerialBuffer", "class_serial_buffer.html", "class_serial_buffer" ],
    [ "SERIAL_BUFFER_MASK", "_serial_buffer_8h.html#a802cf662365d7027fced85e4bfb8b968", null ],
    [ "SERIAL_BUFFER_SIZE", "_serial_buffer_8h.html#aaa07390e6158db5d82d40510d2ae02d5", null ]
];