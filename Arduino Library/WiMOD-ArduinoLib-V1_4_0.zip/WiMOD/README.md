= WiMOD Library for Arduino =

The WiMOD library allows communication to WiMOD radio modules running the
HCI communication protocol used by the IMST LR-Base / LoRaWAN EndeNode Modem
firmware.

This makes a complete example showing all steps of processing WiMOD's HCI 
messages on the low level side. On the high level side the library offers a 
bunch of simple API commands that control the WIMOD modem firmware. Hence a 
prototype of a LoRaWAN endnode can be created in minutes.