var struct_t_wi_m_o_d_l_r___h_c_i_message =
[
    [ "CRC16", "struct_t_wi_m_o_d_l_r___h_c_i_message.html#a354d192c3f91ab18e7976609ba3ef2af", null ],
    [ "Length", "struct_t_wi_m_o_d_l_r___h_c_i_message.html#aa08e7e60eac2968f090c4e5473b644f8", null ],
    [ "MsgID", "struct_t_wi_m_o_d_l_r___h_c_i_message.html#adbefdeedad184a2413bd0f6b8552db0c", null ],
    [ "Payload", "struct_t_wi_m_o_d_l_r___h_c_i_message.html#acd7265ded940579c985d880f25e887b7", null ],
    [ "SapID", "struct_t_wi_m_o_d_l_r___h_c_i_message.html#afac460b8b7a1df9a387f494a0c617c9f", null ]
];