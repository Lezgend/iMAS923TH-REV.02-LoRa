var struct_t_wi_m_o_d_l_o_r_a_w_a_n___join_params =
[
    [ "AppEUI", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___join_params.html#a313d6df4df133e3ade7e73d1bf3f3e8c", null ],
    [ "AppKey", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___join_params.html#a8312ae8958b8f0fa622b32e76ff26f9a", null ]
];