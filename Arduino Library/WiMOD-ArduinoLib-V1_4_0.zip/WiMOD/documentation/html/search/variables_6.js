var searchData=
[
  ['groupaddress',['GroupAddress',['../struct_t_wi_m_o_d_l_r___dev_mgmt___radio_config.html#aaa0b543ec41bcf6d763c4a5cb40f37e2',1,'TWiMODLR_DevMgmt_RadioConfig']]],
  ['groupadr',['GroupAdr',['../struct_t_wi_m_o_d_l_r___dev_mgmt___dev_info.html#a48f977b5d08e2db24ad6be5894aeffde',1,'TWiMODLR_DevMgmt_DevInfo']]]
];
