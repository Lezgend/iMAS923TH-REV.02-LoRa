var searchData=
[
  ['crc16_5fgood_5fvalue',['CRC16_GOOD_VALUE',['../_c_r_c16_8h.html#ab565fe4602fff2131dde7b1de0d4133c',1,'CRC16.h']]],
  ['crc16_5finit_5fvalue',['CRC16_INIT_VALUE',['../_c_r_c16_8h.html#aa8b0311c2e6302e6f540a7129376c442',1,'CRC16.h']]],
  ['crc16_5fpolynom',['CRC16_POLYNOM',['../_c_r_c16_8h.html#a83009878e695ffa15091e426ef55b045',1,'CRC16.h']]]
];
