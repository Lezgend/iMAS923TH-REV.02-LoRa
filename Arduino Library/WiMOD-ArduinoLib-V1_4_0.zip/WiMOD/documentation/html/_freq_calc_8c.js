var _freq_calc_8c =
[
    [ "FreqCalc_calcFreqToRegister", "_freq_calc_8c.html#ac2bd61c2183d22dbcf5f95bda2676e62", null ],
    [ "FreqCalc_calcRegisterToFreq", "_freq_calc_8c.html#a9f3a82537c81953e60c700d2b7a27bfb", null ]
];