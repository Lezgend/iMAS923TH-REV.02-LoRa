var struct_t_wi_m_o_d_l_o_r_a_w_a_n___tx_ind_data =
[
    [ "ChannelIndex", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___tx_ind_data.html#a9b2e45343b3f02e2e5cef953e6a60c71", null ],
    [ "DataRateIndex", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___tx_ind_data.html#a4fb416cce10378513ff4fa4412e65b8b", null ],
    [ "FieldAvailability", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___tx_ind_data.html#a7e60d2d9456084af8651e8da9244aeca", null ],
    [ "NumTxPackets", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___tx_ind_data.html#a83c5bc86ad884ebe20fc4c90f359ce28", null ],
    [ "PowerLevel", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___tx_ind_data.html#a318494dd03a2a4f866a015cd575aea3c", null ],
    [ "RfMsgAirtime", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___tx_ind_data.html#a4153223d5734a410489f411b2e232e5d", null ],
    [ "StatusFormat", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___tx_ind_data.html#a0f4f3dc465ee8f7826970d32175df284", null ]
];