var struct_t_wi_m_o_d_l_r___sys_kit___system_config =
[
    [ "AccessPointID", "struct_t_wi_m_o_d_l_r___sys_kit___system_config.html#a809d943d0136dfb1df622f4e8a3f21bf", null ],
    [ "DeviceID", "struct_t_wi_m_o_d_l_r___sys_kit___system_config.html#a13467ab446c4f9a91b55b297bbe72d49", null ],
    [ "DeviceKey", "struct_t_wi_m_o_d_l_r___sys_kit___system_config.html#af54a45724e1355a5b79d04948f67775b", null ],
    [ "SystemID", "struct_t_wi_m_o_d_l_r___sys_kit___system_config.html#ac79c9f4a0cd0c36f12ad4437cdba7af6", null ]
];