var struct_t_wi_m_o_d_l_o_r_a_w_a_n___t_x___data =
[
    [ "Length", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___t_x___data.html#a32c376f01678c19b091a24774a274d1e", null ],
    [ "Payload", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___t_x___data.html#ae521a38375a5f69b498981fd554240d0", null ],
    [ "Port", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___t_x___data.html#a9fb63e8d79a25ada93a15fac0156984a", null ]
];