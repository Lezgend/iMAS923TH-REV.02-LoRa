var struct_t_wi_m_o_d_l_r___dev_mgmt___dev_info =
[
    [ "DevAdr", "struct_t_wi_m_o_d_l_r___dev_mgmt___dev_info.html#a6ce400f3284d0c158fb1d50305308bb2", null ],
    [ "DevID", "struct_t_wi_m_o_d_l_r___dev_mgmt___dev_info.html#af5ed57820e00838bb212825f64fcd3a2", null ],
    [ "GroupAdr", "struct_t_wi_m_o_d_l_r___dev_mgmt___dev_info.html#a48f977b5d08e2db24ad6be5894aeffde", null ],
    [ "ModuleType", "struct_t_wi_m_o_d_l_r___dev_mgmt___dev_info.html#a43d295455c04558ddaaaf3a8e1f840c3", null ],
    [ "Status", "struct_t_wi_m_o_d_l_r___dev_mgmt___dev_info.html#abb67e72270ddaa6f2046d4b2b981e952", null ]
];