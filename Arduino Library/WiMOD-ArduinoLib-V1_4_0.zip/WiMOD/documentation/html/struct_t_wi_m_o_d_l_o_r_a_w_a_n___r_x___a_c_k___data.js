var struct_t_wi_m_o_d_l_o_r_a_w_a_n___r_x___a_c_k___data =
[
    [ "ChannelIndex", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___r_x___a_c_k___data.html#acc0583ae0ea5cafe23109565ac2c3f8e", null ],
    [ "DataRateIndex", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___r_x___a_c_k___data.html#a75c256225d8fcebb8c7262e3d607e735", null ],
    [ "OptionalInfoAvaiable", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___r_x___a_c_k___data.html#a9180f0cae8b7f62ffd7efc67edfe5e30", null ],
    [ "RSSI", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___r_x___a_c_k___data.html#aa677f769180f8a23d76af26d29804ba8", null ],
    [ "RxSlot", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___r_x___a_c_k___data.html#a9b51522709e64bf2d2a658a6a550fd3e", null ],
    [ "SNR", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___r_x___a_c_k___data.html#a16adfe24b812ec0b1d2177bba524db83", null ],
    [ "StatusFormat", "struct_t_wi_m_o_d_l_o_r_a_w_a_n___r_x___a_c_k___data.html#a4e68627dc0422efb510c8f6882dffabe", null ]
];