var struct_t_wi_m_o_d_l_r___radio_link___cdata_ind =
[
    [ "AirTime", "struct_t_wi_m_o_d_l_r___radio_link___cdata_ind.html#ac53475a470c4c1ace72d619b800bdbd8", null ],
    [ "Status", "struct_t_wi_m_o_d_l_r___radio_link___cdata_ind.html#a0d589c46b53c58994ee7cd228490ee5d", null ],
    [ "TxEventCounter", "struct_t_wi_m_o_d_l_r___radio_link___cdata_ind.html#a5b5dd6af8881140f63b912ba42878b34", null ]
];