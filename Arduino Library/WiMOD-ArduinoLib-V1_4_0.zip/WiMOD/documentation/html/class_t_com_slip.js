var class_t_com_slip =
[
    [ "TComSlip", "class_t_com_slip.html#a51e797693250917acc1b04affd5ec5d8", null ],
    [ "begin", "class_t_com_slip.html#abd18447990befbdd80b95d7d61037429", null ],
    [ "DecodeData", "class_t_com_slip.html#a913dde86445a4ce102657fe5607464e6", null ],
    [ "end", "class_t_com_slip.html#a8c9263d317970e084cc528b9d772d382", null ],
    [ "RegisterClient", "class_t_com_slip.html#a2a8d2d8487767f7bddcb6eab2d85d107", null ],
    [ "SendMessage", "class_t_com_slip.html#a6ff55a9ae6fe05dbd73f0c5b2b1512ca", null ],
    [ "SendWakeUpSequence", "class_t_com_slip.html#ae9f4258139b4518c51e2b497fd556d49", null ],
    [ "SetRxBuffer", "class_t_com_slip.html#a954f43d6bfe0c14aedf4150c310ea97b", null ]
];