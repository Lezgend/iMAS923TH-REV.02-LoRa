var struct_t_wi_m_o_d_l_r___radio_link___msg =
[
    [ "DestinationDeviceAddress", "struct_t_wi_m_o_d_l_r___radio_link___msg.html#af6da7d1b826fb055b3a5fb6d42fc1c33", null ],
    [ "DestinationGroupAddress", "struct_t_wi_m_o_d_l_r___radio_link___msg.html#aa5431fbfcbc6448b673c8fe0396ac371", null ],
    [ "Length", "struct_t_wi_m_o_d_l_r___radio_link___msg.html#ac86811fb13a98a9736be54f4a979c61e", null ],
    [ "MIC", "struct_t_wi_m_o_d_l_r___radio_link___msg.html#aa5bab34ed85e2c5193feb1723d75e98c", null ],
    [ "OptionalInfoAvaiable", "struct_t_wi_m_o_d_l_r___radio_link___msg.html#a3db49fece253b57a09ded050379b920f", null ],
    [ "Payload", "struct_t_wi_m_o_d_l_r___radio_link___msg.html#ab02a343ebfc3b5a8cc97ad89abe0eb23", null ],
    [ "RSSI", "struct_t_wi_m_o_d_l_r___radio_link___msg.html#a4e8f93735759bf106cae45734ad1e62f", null ],
    [ "RxTime", "struct_t_wi_m_o_d_l_r___radio_link___msg.html#a385ca0da1e390d539ad92ed124bc6f45", null ],
    [ "SNR", "struct_t_wi_m_o_d_l_r___radio_link___msg.html#ac6e70bed33c0d442f0ca8de02f155f8d", null ],
    [ "SourceDeviceAddress", "struct_t_wi_m_o_d_l_r___radio_link___msg.html#a2457d3da90b6799dd5779ca80e8b3a54", null ],
    [ "SourceGroupAddress", "struct_t_wi_m_o_d_l_r___radio_link___msg.html#a8e7b553e49e25a3ea78919a02e43a8f7", null ],
    [ "StatusFormat", "struct_t_wi_m_o_d_l_r___radio_link___msg.html#a51afd18ed7ff0c4f867dbc0e05ebe7b3", null ]
];